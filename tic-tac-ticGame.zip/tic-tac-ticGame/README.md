# Project 2 - Tic-Tac-Toe Java Game

This is a two-player Tic-Tac-Toe game written in Java with a clickable board.

## Files

- `src/Main.java` - Tic-Tac-Toe GUI source code
- `run.ps1` - compiles and runs the program

## Run

From this folder, use:

```powershell
.\run.ps1
```

Or compile and run manually:

```powershell
javac -d out src/Main.java
java -cp out Main
```

## How To Play

Players take turns clicking the cells. The first player to place three marks
in a row, column, or diagonal wins. Use `Reset Game` to start again.
