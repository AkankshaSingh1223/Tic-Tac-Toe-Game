import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class Main {
    private static final int BOARD_SIZE = 3;
    private static final char EMPTY = ' ';
    private static final char PLAYER_X = 'X';
    private static final char PLAYER_O = 'O';

    private final char[][] board = new char[BOARD_SIZE][BOARD_SIZE];
    private final JButton[] cells = new JButton[9];
    private final JLabel statusLabel = new JLabel("Player X's turn", SwingConstants.CENTER);
    private char currentPlayer = PLAYER_X;
    private boolean gameOver = false;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().createAndShowGui());
    }

    private void createAndShowGui() {
        JFrame frame = new JFrame("Tic-Tac-Toe");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 520);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout(12, 12));

        statusLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        statusLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(16, 12, 8, 12));
        frame.add(statusLabel, BorderLayout.NORTH);

        JPanel boardPanel = new JPanel(new GridLayout(3, 3, 8, 8));
        boardPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 12, 12, 12));

        Font cellFont = new Font("SansSerif", Font.BOLD, 42);
        for (int i = 0; i < cells.length; i++) {
            JButton button = new JButton("");
            button.setFont(cellFont);
            button.setFocusPainted(false);
            button.setBackground(Color.WHITE);
            button.addActionListener(e -> handleMove((JButton) e.getSource()));
            cells[i] = button;
            boardPanel.add(button);
        }

        frame.add(boardPanel, BorderLayout.CENTER);

        JPanel controls = new JPanel();
        JButton resetButton = new JButton("Reset Game");
        resetButton.setFont(new Font("SansSerif", Font.PLAIN, 18));
        resetButton.addActionListener(e -> resetGame());
        controls.add(resetButton);
        frame.add(controls, BorderLayout.SOUTH);

        resetBoardState();
        frame.setVisible(true);
    }

    private void handleMove(JButton button) {
        if (gameOver || !button.getText().isEmpty()) {
            return;
        }

        int index = getButtonIndex(button);
        int row = index / BOARD_SIZE;
        int col = index % BOARD_SIZE;

        board[row][col] = currentPlayer;
        button.setText(String.valueOf(currentPlayer));
        button.setForeground(currentPlayer == PLAYER_X ? new Color(180, 50, 50) : new Color(45, 90, 180));

        if (hasWon(currentPlayer)) {
            endGame("Player " + currentPlayer + " wins!");
        } else if (isDraw()) {
            endGame("It's a draw!");
        } else {
            currentPlayer = switchPlayer(currentPlayer);
            statusLabel.setText("Player " + currentPlayer + "'s turn");
        }
    }

    private int getButtonIndex(JButton button) {
        for (int i = 0; i < cells.length; i++) {
            if (cells[i] == button) {
                return i;
            }
        }

        return -1;
    }

    private void endGame(String message) {
        gameOver = true;
        statusLabel.setText(message);

        for (JButton cell : cells) {
            cell.setEnabled(false);
        }

        JOptionPane.showMessageDialog(null, message, "Game Over", JOptionPane.INFORMATION_MESSAGE);
    }

    private void resetGame() {
        resetBoardState();
        currentPlayer = PLAYER_X;
        gameOver = false;
        statusLabel.setText("Player X's turn");

        for (JButton cell : cells) {
            cell.setText("");
            cell.setEnabled(true);
            cell.setForeground(Color.BLACK);
        }
    }

    private void resetBoardState() {
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                board[row][col] = EMPTY;
            }
        }
    }

    private boolean hasWon(char player) {
        for (int index = 0; index < BOARD_SIZE; index++) {
            boolean rowWin = board[index][0] == player
                    && board[index][1] == player
                    && board[index][2] == player;
            boolean columnWin = board[0][index] == player
                    && board[1][index] == player
                    && board[2][index] == player;

            if (rowWin || columnWin) {
                return true;
            }
        }

        boolean leftDiagonalWin = board[0][0] == player
                && board[1][1] == player
                && board[2][2] == player;
        boolean rightDiagonalWin = board[0][2] == player
                && board[1][1] == player
                && board[2][0] == player;

        return leftDiagonalWin || rightDiagonalWin;
    }

    private boolean isDraw() {
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                if (board[row][col] == EMPTY) {
                    return false;
                }
            }
        }

        return true;
    }

    private char switchPlayer(char player) {
        return player == PLAYER_X ? PLAYER_O : PLAYER_X;
    }
}
