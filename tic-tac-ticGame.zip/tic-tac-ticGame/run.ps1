$ErrorActionPreference = "Stop"

if (-not (Test-Path "out")) {
    New-Item -ItemType Directory -Path "out" | Out-Null
}

javac -d out src/Main.java
java -cp out Main
